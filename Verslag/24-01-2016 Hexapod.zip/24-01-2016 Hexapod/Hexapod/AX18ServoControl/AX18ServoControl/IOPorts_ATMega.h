/*
 * IOPorts_ATMega.h
 *
 * Created: 10-9-2015 11:40:42
 *  Author: m
 */ 


#ifndef IOPORTS_ATMEGA_H_
#define IOPORTS_ATMEGA_H_

#define PIN0_bm 0x01
#define PIN1_bm 0x02
#define PIN2_bm 0x04
#define PIN3_bm 0x08
#define PIN4_bm 0x10
#define PIN5_bm 0x20
#define PIN6_bm 0x40
#define PIN7_bm 0x80


#endif /* IOPORTS_ATMEGA_H_ */